<?php

include 'config.php';

$nome = $_POST['nome'];
$email = $_POST['email'];
$idade = $_POST['idade'];

//inserindo os dados no Banco

$sql = "INSERT INTO usuarios (nome, email, idade) VALUES ('$nome', '$email', '$idade')";

if($conexao->query($sql)){
    echo 'Seus dados foram cadastrados com sucesso!!';
}else{
    echo 'Houve algum erro na conexão';
}


?>