<?php

$servidor = 'localhost';
$login = 'root';
$senha = '';
$bd = 'exemplo_db';

// conexão
$conexao = new mysqli($servidor, $login, $senha, $bd); // a variavel conexão é o equivale a banco de dados

//if($conexao->connect_error){
//   echo 'Conexão efetuada com sucesso !!!';
//}else{
//  echo 'Erro Erro Erro';
//}


?>