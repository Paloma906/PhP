<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilos.css">

</head>
<body>
    <div class="central">
        <?php
        // receber as variaveis globais
        $nome = $_POST['nome'];
        $peso = $_POST['peso'];
        $altura = number_format($_POST['altura'],2);
        $hipertenso = $_POST['hipertenso'];

        //calculo do imc
        $imc = round($peso/($altura*$altura),2);

        // condições do IMC

        if($imc<18.5){
            $situacao = 'Magro';
        }
        elseif($imc>=18.5 && $imc <25){
            $situacao = 'Normal';
        }
        elseif($imc>=25 && $imc <30){
            $situacao = 'Sobrepeso';
        }
        elseif($imc>=30 && $imc <35){
            $situacao = 'Obesidade leve';
        }else{
            $situacao = 'Obesidade Grau 2';
        }

        //exibir o resultado dentro da div

        //echo '<h2> O seu imc é de: </h2>'.$imc.'<h2> A sua situacao é de </h2>'.$situacao;

        echo "<h2>O seu imc é {$imc}, você está {$situacao}</h2>";


        ?>




                                                           
    </div>
</body>
</html>