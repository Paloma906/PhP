<?php

$senha = 21022007;
$senha_cripto = md5($senha);
echo $senha_cripto;

?>: