<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos.css">
    <title>Principal</title>
</head>
<body>
    <div class="container">
        <h1>Bem-vindo!</h1>
        <div class="button-container">
            <a href="cadastro.html" class="button">Cadastro</a>
            <a href="lista.php" class="button">Listagem</a>
            <a href="busca.php" class="button">Busca</a>
        </div>
    </div>
</body>
</html>
