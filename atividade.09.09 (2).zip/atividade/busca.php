<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="busca.css">
    <title>Busca dos alunos</title>
</head>
<body>
    <div class="message-container">
        <h1>Buscando Alunos</h1>
        
        <!-- Formulário de Busca -->
        <form method="POST" action="busca.php">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" value="">

            <label for="escolaridade">Escolaridade:</label>
            <input type="text" id="escolaridade" name="escolaridade" value="">

            <label for="serie">Série:</label>
            <input type="text" id="serie" name="serie" value="">

            <button type="submit">Buscar</button>
        </form>

        <?php
        include 'conect.php';

        // Criação da consulta SQL com base nos parâmetros de busca
        $nome = isset($_POST['nome']) ? $conexao->real_escape_string($_POST['nome']) : '';
        $escolaridade = isset($_POST['escolaridade']) ? $conexao->real_escape_string($_POST['escolaridade']) : '';
        $serie = isset($_POST['serie']) ? $conexao->real_escape_string($_POST['serie']) : '';

        $sql = "SELECT * FROM estudantes WHERE ";
        

        if ($nome) {
            $sql .= "nome LIKE '%$nome%'";
        }

        if ($escolaridade && $nome) {
            $sql .= " AND escolaridade LIKE '%$escolaridade%'";
            // $sql .= "escolaridade LIKE '%$escolaridade%'";
        }elseif($escolaridade){
            $sql .= "escolaridade LIKE '%$escolaridade%'";
        }
        
       
        if ($serie && $nome && $escolaridade) {
            // $sql .= " AND serie LIKE '%$serie%'";
            $sql .= "AND serie LIKE '%$serie%'";
        }elseif($serie && $escolaridade || $serie && $nome) {
            $sql .= " AND serie LIKE '%$serie%'";
        }elseif($serie){
            $sql .= "serie LIKE '%$serie%'";
        }

        $resultado  = $conexao->query($sql);
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if ($resultado->num_rows > 0) {
                echo '<table>';
                echo '<thead>
                        <tr>
                            <th>Nome</th>
                            <th>Escolaridade</th>
                            <th>Série</th>
                        </tr>
                      </thead>';
                echo '<tbody>';
                while ($linha = $resultado->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($linha["nome"]) . '</td>';
                    echo '<td>' . htmlspecialchars($linha["escolaridade"]) . '</td>';
                    echo '<td>' . htmlspecialchars($linha["serie"]) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
            } else {
                echo '<p>Nenhum estudante encontrado com os critérios fornecidos.</p>';
            }
        }
        
        ?>

        <a href="index.html" class="back-button">Voltar</a>
    </div>
</body>
</html>
