<?php
include 'conect.php';

$id = $_POST ['BtnExcluir'];

$sql = "DELETE FROM `escola`.`estudantes` WHERE (`id` = '$id');";
echo $sql;

if($conexao -> query($sql)){
    echo "<script>alert('Deletado com sucesso')</script>";
}else{
    echo "<script>alert('Erro ao deletar')</script>";
}

header('location: ./lista.php');

?>