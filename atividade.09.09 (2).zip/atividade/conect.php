<?php
//VARIAVEIS GLOBAIS
$servidor = 'localhost'; 
$login = 'root';
$senha = '';
$bd = 'escola';

//CONEXÃO
($conexao = new mysqli($servidor, $login, $senha, $bd))

//if($conexao = new mysqli($servidor, $login, $senha, $bd)){
//    echo "sucessro";
//}else{
//    echo $conexao -> error();
//}

?>