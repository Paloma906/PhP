<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="busca.css">
    <title>Lista dos Alunos</title>
</head>

<body>
    <div class="message-container">
        <h1>Lista de Estudantes Cadastrados</h1>
        <?php
        include 'conect.php';

        $sql = "SELECT * FROM estudantes";
        $resultado = $conexao->query($sql);

        if ($resultado->num_rows > 0) {

            // echo '<form action="lista.php" method="POST">';
            echo '<table>';
            echo '<thead>
            <tr>
            <th>Nome</th>
            <th>Escolaridade</th>
            <th>Série</th>
            <th> </th>
            <th> </th>
            </tr>
            </thead>';
            echo '<tbody>';
            while ($linha = $resultado->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($linha["nome"]) . '</td>';
                echo '<td>' . htmlspecialchars($linha["escolaridade"]) . '</td>';
                echo '<td>' . htmlspecialchars($linha["serie"]) . '</td>';
                
                
               echo '<td>' .'<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                  Editar
                </button>
                
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        ...
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                      </div>
                    </div>
                  </div>
                </div>' . '</td>';

                // echo '<td><form method="post" action="editar.php"><button type="submit" name="BtnEditar" value="' . htmlspecialchars($linha['id']) . '" class="btn btn-warning">Editar</button></form></td>';
                echo '<td><form method="post" action="excluir.php"><button type="submit" name="BtnExcluir" value="' . htmlspecialchars($linha['id']) . '" class="btn btn-danger">Excluir</button></form></td>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
            // echo '</form>';
        } else {
            echo '<p>Nenhum estudante cadastrado.</p>';
        }
        ?>
        <a href="index.html" class="back-button">Voltar</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>