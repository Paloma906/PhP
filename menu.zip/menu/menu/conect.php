<?php

$servidor = 'localhost';
$login = 'root';
$senha = '';
$banco = 'escola';

$conexao = new mysqli($servidor, $login, $senha, $banco);

/*if ($conexa -> conenect_error){
    echo 'Erro!';
} else{
    echo 'Conexão efetuada com sucesso!';
}
*/ 
?>;