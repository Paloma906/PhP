<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Aluno</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(270deg, #0033A0, #009DCF, #0015c0);
            background-size: 600% 600%;
            animation: gradientAnimation 8s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 600px;
            width: 100%;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button[type="submit"] {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
            display: block;
            width: 100%;
        }

        button[type="submit"]:hover {
            background-color: #218838;
        }

        .success-message, .error-message {
            text-align: center;
            margin-top: 20px;
        }

        .success-message {
            color: green;
            font-weight: bold;
        }

        .error-message {
            color: red;
            font-weight: bold;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #007BFF;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Cadastro de Aluno</h1>
        <form action="cadastro.php" method="post">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="escolaridade">Escolaridade:</label>
            <input type="text" id="escolaridade" name="escolaridade" required>

            <label for="serie">Série:</label>
            <input type="text" id="serie" name="serie" required>

            <button type="submit">Cadastrar</button>
        </form>

        <?php
        include 'conect.php';

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nome = $_POST['nome'];
            $escolaridade = $_POST['escolaridade'];
            $serie = $_POST['serie'];

            $sql = "INSERT INTO estudantes (nome, escolaridade, serie) 
                    VALUES ('$nome', '$escolaridade', '$serie')";

            if ($conexao->query($sql)) {
                echo '<p class="success-message">Seus dados foram cadastrados com sucesso!</p>';
            } else {
                echo '<p class="error-message">Houve algum erro na conexão.</p>';
            }
        }
        ?>

        <a class="back-link" href="index.php">Voltar ao início</a>
    </div>
</body>
</html>
