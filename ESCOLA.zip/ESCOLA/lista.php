<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="message-container">
        <?php

        include 'conect.php';


        $sql = "SELECT * FROM new_table";

        $resultado = $conexao->query($sql);

        if($resultado->num_rows>0){

            while($linha = $resultado->fetch_assoc()){
                echo $linha["nome"].'<br>';
                echo $linha["escolaridade"].'<br>';
                echo $linha["serie"].'<br>';
            }
        }else{
            echo 'Dados não encontrados !!';
        }


        ?>
        
    </div>
</body>
</html>