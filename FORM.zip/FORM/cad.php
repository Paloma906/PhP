<?php

$nome = $_POST['nome'];
$school = $_POST['escolaridade'];
$genero = $_POST['genero'];
$comente = $_POST['coment'];


echo 'Seu nome é' .$nome.'<br>';
echo 'Sua escolaridade é' .$school;
echo 'Seu genero é' .$genero;
echo 'Seu comentário foi' .$comente;


?>