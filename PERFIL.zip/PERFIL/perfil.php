<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilos.css">

</head>
<body>
    <div class="central">
        <?php
         // Atribuir valores às variáveis
    $nome = $_POST['nome'];
    $quantidade_filhos = $_POST['quant'];
    $escolaridade = $_POST['escolaridade'];
    $cargo = $_POST['cargo'];
    $salario_base = $_POST['salario'];
    
   
    // Função para calcular o salário
    function calcular_salario($quantidade_filhos, $escolaridade, $cargo, $salario_base){
        // Adicionar valor ao salário com base na quantidade de filhos

        switch($cargo){
            case "professor":
                $salario_base += 50;
                break;
                case "coordenador":
                    $salario_base += 650;
                    break;
                    case "superintendente":
                        $salario_base += 900;
                        break;
                        case "diretor":
                            $salario_base += 2000;
                            break;
                            default:
                            echo "Desempregado";
                            break;
                        }
                        
                        if ($quantidade_filhos >= 2){
                            $salario_base += $salario_base * 0.05;
                        } 
                        if ($escolaridade == 'mestrado' || $escolaridade == 'doutorado'){
                            $salario_base += $salario_base * 0.1;
                        }

        return $salario_base;
    }
    
    // Calcular o salário atualizado
    $salario_atualizado = calcular_salario($quantidade_filhos, $escolaridade, $cargo, $salario_base);
    $salario_atualizado = number_format($salario_atualizado,2);
    // Exibir o salário atualizado
    //echo " O seu novo salário é: R$".number_format($salario_atualizado, 2);
    echo "<h2>{$nome}, o seu sálario é: {$salario_atualizado}</h2>";
    




        ?>
        
       
    </div>
</body>
</html>